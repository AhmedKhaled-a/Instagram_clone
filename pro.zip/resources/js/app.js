import './bootstrap';

import '../sass/app.scss';

// import 'bootstrap/dist/css/bootstrap.min.css';

import Alpine from 'alpinejs';
import 'bootstrap';

window.Alpine = Alpine;
Alpine.start();
