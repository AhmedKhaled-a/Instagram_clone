@include("posts.index")

